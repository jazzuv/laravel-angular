<?php
session_start();
include "conn.php";


  if(isset($_POST) && !empty($_POST)){
	$name=$_POST['name'];
	$email=$_POST['email'];
	$password=$_POST['password'];


	$sql = "SELECT * FROM login WHERE email='$email' AND password='$password'";
//echo "<pre>";
//print_r($sql);
//die;
	$result = mysqli_query($conn,$sql);
	$row = mysqli_fetch_array($result);

	if(!$row) {
		header('Location:login.php?err');
	}
	else{
	    $_SESSION['name'] =$row['name'];
		$_SESSION['id']=$row['id'];
		header('Location:dashboard.php');
     }
}


?>