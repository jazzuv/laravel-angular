<?php 
session_start();
include "conn.php";

 $Userid= $_SESSION['id'];



  if(!empty($_GET['id']) || !empty($Userid)){

    if($_GET['id']){
        $id= $_GET['id'];
    }else{
       $id= $Userid;
    }
    
      $q= "SELECT * FROM login WHERE id='".$id."'"; 
      $result=mysqli_query($conn,$q);
      $UserData= mysqli_fetch_assoc($result);
     
    }
    
         
     if(isset($_POST['submit'])){
      
      $name=$_POST['name'];
      $email=$_POST['email'];
      $password=$_POST['password'];
      $firstname=$_POST['firstname'];
      $lastname=$_POST['lastname'];
      $gender = $_POST['gender'];
      $mobilenumber = $_POST['mobilenumber'];
      $qualification = $_POST['qualification'];
      $language=implode(', ',$_POST['language']); 
      $address=$_POST['address'];
      $zip=$_POST['zip'];
         
 
    $query= "UPDATE login SET name='".$name."', firstname='".$firstname."', lastname='".$lastname."', email='".$email."',gender='".$gender."', mobilenumber='".$mobilenumber."', qualification='".$qualification."', language='".$language."', address='".$address."',zip='".$zip."' WHERE id='".$id."'";
   
      mysqli_query($conn, $query);
      header("Location:profile.php");
  }
 ?>




<!doctype html>
  <html lang="en">
    <head>
      <title>form</title>
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script src="https://cdn.jsdelivr.net/jquery.validation/1.15.1/jquery.validate.min.js"></script>
      <link rel="stylesheet" type="text/css" href="index.css">
      <style type="text/css">
      .error {
        color: #ff0000;
       }
      </style>
      </head>
      <body>

        <nav class="navbar navbar-expand-lg">
          <div class="collapse navbar-collapse" id="navbarTogglerDemo01">   
            <ul class="navbar-nav mr-auto py-2 mt-lg-0">
              <li class="nav-item active">
                <a class="nav-link" href="dashboard.php"><b>DASHBOARD</b></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="profile.php"><b>PROFILE</b></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="chat.php"><b>CHAT</b></a>
              </li>
            </ul>
          </div>
        </nav>
        <div class="container-fluid">
          <div class="row">
            <div class="col-sm-3 mt-5">
              <div class="card" style="width: 18rem;">
                
                <img class="card-img-top img-rounded " src="dummy.png" alt="Card image cap">
                <div class="card-body">
                 <?php echo "<h5 class='card-title text-center'>Username: <b>".$UserData['name']."</b></h5>"; ?>
                    
                  <ul class="list-group list-group-flush">
                  <li class="list-group-item">

                  <?php echo "First name: ".$UserData['firstname'];?>
                  </li>

                  <li class="list-group-item">
                  <?php echo "Last name: ".$UserData['lastname'];?>
                  </li>
                  
                  <li class="list-group-item">   
                  <?php echo "Email Id: ".$UserData['email'];?>
                  </li>


                  <li class="list-group-item">
                    <a href="todo.php"> <button type="button" class="btnn btn btn-dark mx-3">TO-DO-LIST</button></a>
                  </li>
             </ul>
          </div>
       </div>
   </div>

<div class="col-md-1">
</div>

            <div class="content col-sm-5 col-md-6 mt-5 ml-5 mb-2">

              <div class="font text-center mt-3 mb-3 pt-2 pb-1"> 
               <h4><b>User Details</b> </h4>
              </div>

        <form class="form_in mb-3 mt-1 pb-2" name="profile" id="profile" action="profile.php" method="post">
        
          <div class="form-row pt-3">
              <div class="form-group col-md-5 ml-4">
                <label for="firstname"> First Name: </label>
                <input type="text" placeholder="Enter your first name" name="firstname" class="form-control" id="firstname" value="<?php echo $UserData['firstname'];?>">
               </div>

              <div class="form-group col-md-5 ml-4">
                <label for="lastname"> Last Name: </label>
                <input type="text" placeholder="Enter your last name" name="lastname" class="form-control" id="lastname" value="<?php echo $UserData['lastname'];?>">
              </div>
        </div>

        <div class="form-row">
              <div class="form-group col-md-5 ml-4">
                <label for="name">Username: </label>
                <input type="text" placeholder="Enter your username" name="name" class="form-control" value="<?php echo $UserData['name']; ?>"> 
              </div>
        
              <div class="form-group col-md-5 ml-4">
                <label for="email"> Email:</label>
                <input type="email" placeholder="Enter your email" name="email" class="form-control" id="email" value="<?php echo $UserData['email']; ?>">
              </div>
          </div>

          <div class="form-row">

            <div class="form-group col-md-6 ml-4">
              <label for="gender"> Gender: </label>

                <div class="form-check">
                  <label for="female">Female</label>
                  <input type="radio" name="gender" value="female" id="female" checked>
      
                   <label for="male">Male</label>
                   <input type="radio" name="gender" value="male" id="male">
                       
                  <label for="other">Other</label>
                  <input type="radio" name="gender" value="other" id="other">
               
                   <?php echo $UserData['gender'];?>
                 </div>
               </div>
            
             <div class="form-group col-md-4">
                 <label for="mobile number"> Mobile Number:</label>
                 <input type="number" class="control" pattern="[0-9]{3}-[0-9]{3}-[0-9]{4}" name="mobilenumber" placeholder="Enter the phone no." id="mobilenumber" value="<?php echo $UserData['mobilenumber'];?>">
              </div>

            </div>
            
           <div class="form-row">

            <div class="form-group col-md-5 ml-4">
             <label for="qualification">Qualification:</label>
              <select class="form-control" id="qualification" name="qualification">
                <option value="post graduation">Post Graduate</option>
                <option value="Graduate">Graduate</option>
                <option value="12th">12th</option>
                <option value="10th">10th</option>
                 <?php echo $UserData['qualification'];?>
              </select>
           </div>

           <div class="form-group col-md-5 ml-4">
            <label for="language[]">Languages:</label>
             <select multiple class="form-control" id="language" name="language[]" required>
                <option value="PHP">PHP</option>
                <option value="JAVA">JAVA</option>
                <option value="ANDROID">ANDROID</option>
                <option value="RUBY ON RAILS">RUBY ON RAILS</option>
                <?php echo $UserData['language[]'];?>
             </select>
          </div>
        </div>
        
        <div class="form-row">
          <div class="form-group col-md-5 ml-4">
           <label for="address" >Address:</label>
            <textarea class="form-control" rows="1" name="address" id="address" required> 
              <?php echo $UserData['address'];?>	
            </textarea>
          </div>
          
          <div class="form-group col-md-5 ml-4 mt-2">
           <label for="zip">Zip:</label>
            <input type="number" class="form-control" id="zip" name="zip">
              <?php echo $UserData['zip'];?> 
           </div>

          </div>

        <div class="form-row">
          <div class="col-md-4 mt-2 ml-4"></div> 
         <button type="submit" name="submit" class="btn btn-danger btn-md mx-3"> SUBMIT </button>
       </div>
    
      </form>
    </div>
  </body>
</html>
<script type="text/javascript">

   $(document).ready(function(){ 
     $("#profile").validate({

      rules: {

      firstname: "required",
      lastname: "required",
      name: "required",
      
      language:"required",
      address:"required",
      mobilenumber: {required:true,
        minlength: 10,
        maxlength:10

      },
      email: {
        required: true,
        email: true
      },

      zip: {
        required: true,
        minlength: 6,
        maxlength:6
      },

       address: {
          required: true,
          minlength: 5
        },
    },
    
    messages: {
      firstname: "Please enter your firstname",
      lastname: "Please enter your lastname",
      name: "Please enter your username",
      mobilenumber:{
        required: "Please enter the mobile number",
        minlength: "Your mobile number must have 10 digits",
        maxlength: "Your mobile number must have 10 digits"
      },
      
      address: {
        required: "Please enter the your address",
        minlength: "Your address must have 6 letters"
      },

      zip: {
        required: "Please enter the zip code",
        minlength: "Your zip code must have 6 digits",
        maxlength: "Your zip code must have 6 digits"
      },
       email: "Please enter a valid email address"
    },
    
    submitHandler: function(form) {
      form.submit();
    }
  });
});

</script>  
