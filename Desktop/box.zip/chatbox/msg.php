<?php
session_start();
include ('conn.php');

$msg=$_POST['msg'];
$name=$_SESSION['name'];


$sql="INSERT INTO chat(msg,name) VALUES('$msg','$name')";


//result = mysqli_query($conn, $sql);

if (mysqli_query($conn, $sql)) {
    echo "New record created successfully";
    header("location:chat.php");
    
} else {
    echo "Error: " . $sql . "<br>" .mysqli_error($conn);
}


?>
