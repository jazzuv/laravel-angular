<?php 
session_start();
include "conn.php";


?>
<!doctype html>
  <html lang="en">
    <head>
      <title>login form</title>
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" >
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script src="https://cdn.jsdelivr.net/jquery.validation/1.15.1/jquery.validate.min.js"></script>
      <link rel="stylesheet" type="text/css" href="form.css">
      
      <script>  

      </script>  
      </head>
      <body>

       <div class="container-fluid">
         
         <div class="row d-flex justify-content-center"> 
          <div class="px-2 mt-5">

            <a href="login.php"> 
              <button type="submit" class="submit btn btn-default mb-2 mt-2 mx-5"><b>LOGIN</b> 
              </button>
            </a>

            <a href="form.php">   
              <button type="submit" class="submit btn btn-default mb-2 mt-2 mx-5"><b>SIGN UP</b> </button>
            </a>
          </div>
        </div>

      <div class="container">
          <div class="row d-flex justify-content-center mt-4"> 
            <div class="content col-sm-4 col-md-4 col-xs-12 mb-2 px-2 py-2">

              <div class="font text-center text-uppercase mt-2 mx-3 pt-1 px-0"> 
               <h4><b>Login </b> </h4>
              </div>

              <form class="form_in px-3" name="login" id="login" action="loginform.php" method="post">


                <div class="form-group">
                 <label for="email"> Email:</label>
                 <input type="email" placeholder="Enter your email" name="email" class="form-control" id="email">
                </div>

                <div class="form-group">
                 <label for="password"> Password:</label>
                 <input type="password" placeholder="Enter your password" name="password" class="form-control" id="password">
                </div>
   
                <button type="submit" class="submit btn btn-default mb-2">LOGIN
                </button>
              </form>
            </div>
          </div>
        </div>
   
  </body>
</html>
 <script type="text/javascript">

        $(document).ready(function(){ 
        $("#login").validate({

      rules: {
      
      
      email: {
        required: true,
       
        email: true
      },
      password: {
        required: true,
        minlength: 5
      }
    },
    
    messages: {

      password: {
        required: "Please enter the password",
        minlength: "Your password must be at least 5 characters long"
      },
      email: "Please enter a valid email address"
    },
    
    submitHandler: function(form) {
      form.submit();
    }
  });
});

</script>