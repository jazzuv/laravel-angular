<?php
session_start();
include "conn.php";

if(!empty($_GET['selectedUserId'])){
    $SeletedUserID = $_GET['selectedUserId'];
    $LoginUserID = $_SESSION['id'];

    $query = "SELECT chats.msg, login.name FROM chats LEFT JOIN login
   ON chats.sid = login.id WHERE (chats.sid = ".$LoginUserID." AND chats.rid = ".$SeletedUserID.") OR (chats.rid = ".$LoginUserID." AND chats.sid = ".$SeletedUserID.") ORDER BY chats.id ASC"; 
  //echo "<pre>";
  //print_r($query);
  //die;
    $resultChatData = mysqli_query($conn,$query);     
}


    if(isset($_POST) && !empty($_POST))
    
  {  
    $msg=$_POST['msg'];
    $name=$_SESSION['name'];
    $SelectedUser = $_POST['SelectedUser'];
    
    $sql='INSERT INTO chats(msg,name,sid,rid) VALUES("'.$msg.'","'.$_SESSION['name'].'","'.$_SESSION['id'].'","'.$SelectedUser.'")';

    $result=$conn->query($sql);  
}

?>

 <!doctype html>
   <html lang="en">
     <head>
      <title>chat</title>
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
      <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
      <script src="https://cdn.jsdelivr.net/jquery.validation/1.15.1/jquery.validate.min.js"></script>
      <link rel="stylesheet" type="text/css" href="index.css">
    </head>
    <body>
    <nav class="navbar navbar-expand-lg">
       <div class="collapse navbar-collapse" id="navbarTogglerDemo01">   
          <ul class="navbar-nav mr-auto py-2 mt-lg-0">
            <li class="nav-item active">
              <a class="nav-link" href="dashboard.php"><b>DASHBOARD</b></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="profile.php"><b>PROFILE</b></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="chat.php"><b>CHAT</b></a>
            </li>
            <li class="nav-item">
              <a href="logout.php"><button type="submit" class="btn btn-success">LOGOUT</button></a>
            </li>
          </ul>
        </div>
    </nav>

    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-3 mt-5 ml-5">
          <h4> Friends List </h4>
            <form class="mb-3 mt-1 pb-2" method="post" action="">
              <select name="SelectedUser" id="SelectedUser">
                <option selected="selected" value="">
                </option>
                <?php 
                  $sq = 'SELECT * FROM login WHERE id != "'.$_SESSION['id'].'"'; 
                  
                  $res = mysqli_query($conn,$sq); 
                  while ($row = $res->fetch_assoc())   
                  {                              
                  $id = $row['id'];
                  $name = $row['name']; ?>
                    <option value='<?php echo $id; ?>' <?php if(!empty($SeletedUserID) && ($SeletedUserID == $id)){ echo "selected=selected";} ?> >  <?php echo $name; ?> </option>;
                  <?php 
                   }  
                 ?>
              </select>
       </div>  
    
      <div class="content col-md-5 mt-5 ml-2">
          <div class="message mt-3 py-5">
             <?php
                      if(!empty($resultChatData)){
                          while ($row = $resultChatData->fetch_assoc())   
                          {                              
                            echo "<h6 class='user'>". $row['user']. "</h6>";
                              echo "<p class='text'>". $row['msg']. "</p>";
                             
                           }  
                      }   
             ?> 
          </div>
         
          <div class="form-group mt-5">
            <textarea class="form-control" rows="1" name="msg" id="msg" required> </textarea>
          </div>
        
              <button type="submit" name="submit" class="btn btn-danger btn-md mb-2">send</button>         
      </div>

    </form>
   </div>
 </div>
</body>
</html>
<script type="text/javascript">
  $(document).ready(function(){
      $("#SelectedUser").change(function(){
          var SelectedUserId = $(this).val();
          var AppendUrl = "?selectedUserId="+SelectedUserId;
          var fullUrl = "<?php 'http://'.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF']; ?>";
          url = fullUrl + AppendUrl;
          window.location.replace(url);
         
      });
  });

</script>