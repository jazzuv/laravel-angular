
<?php
$servername="localhost";
$username="root";
$pass="toor";
$database="dashboard";


$conn=mysqli_connect($servername,$username,$pass,$database);

if(!$conn){
	die("connection failed".mysqli_connect_error());
}


//mysqli_close($conn);

?>