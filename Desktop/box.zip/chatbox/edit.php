<?php
session_start(); 
include "conn.php";
 
    if(!empty($_GET['id'])){
      
    	$tid=$_GET['id'];
       	$q= "SELECT * FROM profile WHERE t_id='".$_GET['id']."'";
    	$result=mysqli_query($conn,$q);
	    $row= mysqli_fetch_assoc($result);
   	}
    

    if(isset($_POST) && !empty($_POST)){ 
	$tid=$_GET['id'];
    $title = $_POST['title'];
    $description = $_POST['description'];
    $place = $_POST['place'];

    $sql= "UPDATE profile SET title='".$title."', description='".$description."', place='".$place."' WHERE t_id='".$tid."'";
   
	mysqli_query($conn, $sql);
	header("Location:dashboard.php");
  }

?>

<!DOCTYPE html>
<html>
 <head>
	<title> edit </title>
	 <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
      <!-- Bootstrap CSS -->
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
       <link rel="stylesheet" href="index.css">
 </head>
 <body>
 	<nav class="navbar navbar-expand-lg navbar-light bg-light">
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
              
            <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
              
              <li class="nav-item active">
                <a class="nav-link" href="dashboard.php"><b>DASHBOARD</b></a>
              </li>

              <li class="nav-item">
                <a class="nav-link" href="profile.php"><b>PROFILE</b></a>
              </li>

            </ul>
          </div>
        </nav>
		  
		 <div class="container-fluid">
		    <div class="row d-flex justify-content-center"> 
		       <div class="col-sm-8">
		        <table class="table">
		          <thead class="thead-dark">
		            <tr>
		              <th>TITLE</th>
		              <th>DESCRIPTION</th>
		              <th>PLACE</th>
		              <th><a href="add.php"><button type="button" class="btn btn-danger mx-5"><b>ADD</b></button></a></th>
		            </tr>
		          </thead>
		          
		          <form action="" method="post">
			          <tbody>
			            <tr> 
			            	
			              <td><input type="text" name="title" placeholder="title" value="<?php echo $row['title'];?>"></td>

			              <td>
			              	<textarea row="1" placeholder="Description" name="description">
				              	 <?php echo $row['description'];?>	
			              	 </textarea>
			              </td>

			              <td>
			              	<input type="text" name="place" placeholder="place" value="<?php echo $row['place'];?>">
			              </td>

			              <td> <button type="submit" class="btn btn-success">EDIT</button></a>
			              </td>

			            </tr> 
			          </tbody>
		          </form>
		        </table>



</div>
</div>
</div>

</body>
</html>
