<?php 
include "conn.php";

if(isset($_POST['Sign']))
?>

  <!doctype html>
    <html lang="en">
      <head>
          <title>form</title>   
          <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">        
          <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
          <script src="https://cdn.jsdelivr.net/jquery.validation/1.15.1/jquery.validate.min.js"></script>

          <link rel="stylesheet" type="text/css" href="form.css">
          <style type="text/css">
               .error {
        color: #ff0000;
          }
          </style>
      </head>
      <body>

     

       <div class="container-fluid">
         
         <div class="row d-flex justify-content-center"> 
          <div class="px-2 mt-4">

            <a href="login.php"> 
              <button type="submit" class="submit btn btn-default mb-2 mt-2 mx-5"><b>LOGIN</b> 
              </button>
            </a>

            <a href="form.php">   
              <button type="submit" class="submit btn btn-default mb-2 mt-2 mx-5"><b>SIGN UP</b> </button>
            </a>
          </div>
        </div>
    
        <div class="container">
          <div class="d-flex justify-content-center"> 
            <div class="content col-sm-5 col-md-5 mt-4">

              <div class="font text-center text-uppercase mt-4 mx-5 mb-1"> 
               <h4><b>SIGN UP</b> </h4>
              </div>

              <form class="form_in px-1 mb-4 mt-4" name="Signup" id="Signup" action="submit.php" method="post" onsubmit="return validateform()">

              <div class="form-group">
                <label for="firstname"> First Name: </label>
                <input type="text" placeholder="Enter your first name" name="firstname" class="form-control required" id="firstname">
               </div>

              <div class="form-group">
                <label for="lastname"> Last Name: </label>
                <input type="text" placeholder="Enter your last name" name="lastname" class="form-control required" id="lastname">
              </div>

              <div class="form-group">
                <label for="name">Username: </label>
                <input type="text" placeholder="Enter your username" name="name" class="form-control required" id="name">
              </div>

              <div class="form-group">
                <label for="email"> Email:</label>
                <input type="email" placeholder="Enter your email" name="email" class="form-control" id="email">
              </div>

              <div class="form-group">
                <label for="password"> Password:</label>
                <input type="password" placeholder="Enter your password" name="password" class="form-control required" id="password">
              </div>

              <div class="form-group">
                <label for="confirmpassword">Confirm Password:</label>
                <input type="password" placeholder="Re-enter the password" name="confirmpassword" class="form-control" id="confirmpassword">
              </div>
                
             <button type="submit" class="submit btn btn-default ml-4 mb-2 mr-5">REGISTER</button>
             <a href="reset.php"><button type="reset" class=" btn btn-warning mb-2 ml-5">RESET</button></a>
            </form>
         </div>
      </div>
   </div>
   
 </body>
</html>
 <script type="text/javascript">

        $(document).ready(function(){ 
        $("#Signup").validate({

      rules: {
      
      firstname: "required",
      lastname: "required",
      name: "required",
      email: {
        required: true,
       
        email: true
      },
      password: {
        required: true,
        minlength: 5
      }
    },
    
    messages: {
      firstname: "Please enter your firstname",
      lastname: "Please enter your lastname",
      name: "Please enter your username",
      password: {
        required: "Please set password",
        minlength: "Your password must be at least 5 characters long"
      },
      email: "Please enter a valid email address"
    },
    
    submitHandler: function(form) {
      form.submit();
    }
  });
});


</script>  
