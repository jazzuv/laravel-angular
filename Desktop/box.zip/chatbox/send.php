<?php
session_start();
include ('conn.php');
$msg=$_POST['msg'];
$name=$_SESSION['name'];



$sql="INSERT INTO chats(msg,name) VALUES('$msg','$name')";

if (mysqli_query($conn,$sql)) {

    header("location:chat.php");
    
} else {
    echo "Error: " . $sql . "<br>" .mysqli_error($conn);
}


?>
