<?php
session_start();
include "conn.php";
?>

<!doctype html>
 <html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="index.css">
    <title>DASHBOARD</title>

  </head>
  
  <body>

  <nav class="navbar navbar-expand-lg navbar-light bg-light">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
  
    
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
      
      <li class="nav-item active">
        <a class="nav-link" href="dashboard.php"><b>DASHBOARD</b></a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="profile.php"><b>PROFILE</b></a>
      </li>
      <li class="nav-item">
         <a class="nav-link" href="chat.php"><b>CHAT</b></a>
      </li>
    </ul>
  </div>
</nav>



     <div class="row d-flex justify-content-center"> 
      <div class="col-sm-6 mt-5">
        <h4 class="text-center"><b> TO-DO-LIST </b></h4>
         <table class="table">
          <thead class="thead-dark">

            <tr>
              <th>TITLE</th>
              <th>DESCRIPTION</th>
              <th>PLACE</th>   
            </tr>
          </thead>
         
          
                
            <?php

              $sql='SELECT * FROM profile WHERE name ="'.$_SESSION["name"].'"';

              $result = mysqli_query($conn,$sql);

                while($row = mysqli_fetch_array($result)) {

                 echo "<tbody><tr><td>" . $row['title'] . "</td>";

                 echo "<td>" . $row['description'] . "</td>";

                 echo "<td>" . $row['place'] . "</td>";
               }

               ?> 
      
            </tr>

           
          </tbody>
        </table>



</div>
</div>
</div>



    
   
  </body>
</html>