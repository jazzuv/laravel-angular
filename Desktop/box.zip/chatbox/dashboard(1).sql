-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 20, 2018 at 07:05 PM
-- Server version: 5.7.23-0ubuntu0.16.04.1
-- PHP Version: 7.0.30-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dashboard`
--

-- --------------------------------------------------------

--
-- Table structure for table `chats`
--

CREATE TABLE `chats` (
  `msg` text NOT NULL,
  `chat_id` int(4) NOT NULL,
  `last_login` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `name` varchar(30) NOT NULL,
  `status` enum('online','offline') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `chats`
--

INSERT INTO `chats` (`msg`, `chat_id`, `last_login`, `name`, `status`) VALUES
('hiiii', 113, '2018-08-20 12:27:16', 'komal', 'online'),
('hey komal', 114, '2018-08-20 12:28:50', 'anchal', 'online'),
('how are you?', 115, '2018-08-20 12:58:58', 'anchal', 'online');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL DEFAULT 'NOT NULL',
  `email` varchar(50) NOT NULL DEFAULT 'NOT NULL',
  `password` varchar(50) NOT NULL DEFAULT 'NOT NULL',
  `firstname` varchar(100) NOT NULL DEFAULT 'NOT NULL',
  `lastname` varchar(100) NOT NULL DEFAULT 'NOT NULL',
  `gender` varchar(20) NOT NULL DEFAULT 'NOT NULL',
  `mobilenumber` varchar(15) NOT NULL DEFAULT 'NOT NULL',
  `qualification` varchar(50) NOT NULL DEFAULT 'NOT NULL',
  `language` varchar(100) NOT NULL DEFAULT 'NOT NULL',
  `address` varchar(500) NOT NULL DEFAULT 'NOT NULL',
  `image` longblob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `name`, `email`, `password`, `firstname`, `lastname`, `gender`, `mobilenumber`, `qualification`, `language`, `address`, `image`) VALUES
(17, 'komal', 'komal22@gmail.com', '123456', 'komal', 'singh', 'female', '787656453', 'graduation', 'PHP', 'delhi', NULL),
(33, 'anchal', 'anchal@gmail.com', '123456', 'anchal', 'thakur', 'female', '789768567', '10th', 'PHP', 'delhi', NULL),
(41, 'shelja', 'shelja@gmail.com', 'shelja', 'shelja', 'thakur', 'NOT NULL', 'NOT NULL', 'NOT NULL', 'NOT NULL', 'NOT NULL', NULL),
(43, 'NOT NULL', 'NOT NULL', 'NOT NULL', 'NOT NULL', 'NOT NULL', 'female', '9876543209', 'Graduate', 'PHP, JAVA, ANDROID', '              delhi\r\n            ', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `t_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` varchar(100) NOT NULL,
  `description` varchar(500) NOT NULL,
  `place` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`t_id`, `name`, `title`, `description`, `place`) VALUES
(67, 'anchal', 'betasoft solutions', '				              	 				              	 web development	\r\n			              	 	\r\n			              	 ', 'chandigrah'),
(68, 'anchal', 'books', 'english ,hindi', 'solan'),
(69, 'anchal', 'homework', 'school work', 'Delhi'),
(70, 'anchal', 'school', 'project ', 'New Delhi'),
(71, 'anchal', 'travel', 'To explore new place', 'chandigrah'),
(72, 'Shelja Thakur', 'Dashboard', 'assignment', 'moali'),
(74, 'anchal', 'lunch', 'meal', 'canteen'),
(77, 'Ritik Thakur', 'school college', '				              	 homework project\r\n			              	 ', 'Chandigrah'),
(80, 'Ritik Thakur', 'travel', 'traveling', 'himachal'),
(81, 'Ritik Thakur', 'shopping', 'market', 'solan'),
(83, 'komal', 'tuition', 'all subjects', 'Delhi'),
(85, 'komal', 'coaching', 'english', 'chandigrah'),
(86, 'komal', 'travel', 'travel', 'solan'),
(87, 'shelja', 'project', 'online project', 'mohali');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chats`
--
ALTER TABLE `chats`
  ADD PRIMARY KEY (`chat_id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`t_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `chats`
--
ALTER TABLE `chats`
  MODIFY `chat_id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=116;
--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;
--
-- AUTO_INCREMENT for table `profile`
--
ALTER TABLE `profile`
  MODIFY `t_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=88;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
