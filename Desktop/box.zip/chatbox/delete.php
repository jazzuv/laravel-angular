 <?php 
  include ('conn.php');

  $tid=$_GET['id'];

  $query="DELETE FROM profile WHERE t_id='".$_GET['id']."'";

  $del=mysqli_query($conn,$query);

  if($del)
  {
  	header("Location:dashboard.php");
  }
  else
  {
    die("Record is not deleted it is query error.".mysqli_error()); 
  }

  
 ?>