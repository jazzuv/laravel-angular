<?php
include "conn.php";
  
 if(isset($_POST) && !empty($_POST)){
  $name=$_POST['name'];
  $email=$_POST['email'];
  $password=$_POST['password'];
  $firstname=$_POST['firstname'];
  $lastname=$_POST['lastname'];

$sql='INSERT INTO login(name,email,password,firstname,lastname) VALUES("'.$name.'","'.$email.'","'.$password.'","'.$firstname.'","'.$lastname.'")';

//echo "<pre>";
//print_r($sql);
//die;
if ($conn->query($sql) === TRUE) {
    header("Location:dashboard.php");
}
 else {
     header("Location:form.php?err");
}

}

$conn->close();
?>